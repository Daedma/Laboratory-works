package functions;

public class InappropriateFunctionPointException extends Exception {

	public InappropriateFunctionPointException(String errorMessage) {
		super(errorMessage);
	}

	public InappropriateFunctionPointException() {
	}
}
