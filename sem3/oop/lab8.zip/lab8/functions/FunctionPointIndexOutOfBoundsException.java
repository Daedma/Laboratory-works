package functions;

public class FunctionPointIndexOutOfBoundsException extends IndexOutOfBoundsException {

	public FunctionPointIndexOutOfBoundsException(String errorMessage) {
		super(errorMessage);
	}

	public FunctionPointIndexOutOfBoundsException() {
	}
}